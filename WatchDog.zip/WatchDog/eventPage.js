chrome.alarms.onAlarm.addListener(function (alarm) {
  alert("Beep");
});
