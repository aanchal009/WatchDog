function save_options() {
  localStorage["history_size"] = document.getElementById("history_size").value;
  localStorage["edialarm"] = document.getElementById("edialarm").value;
  localStorage["quesalarm"] = document.getElementById("quesalarm").value;

  var status = document.getElementById("status");
  status.innerHTML = "Options Saved.";
  setTimeout(function() {
    status.innerHTML = "";
  }, 750);
}

function restore_options() {
  var history_size = localStorage["history_size"];
  var edialarm = localStorage["edialarm"];
  var quesalarm = localStorage["quesalarm"];
  if(!edialarm){
    return;
  }
  if(!quesalarm)return;
  if (!history_size) {
    return;
  }
  document.getElementById("history_size").value = history_size;
  document.getElementById("edialarm").value = edialarm;
  document.getElementById("quesalarm").value = quesalarm;

}

document.addEventListener('DOMContentLoaded', restore_options);
document.querySelector('#save').addEventListener('click', save_options);
